import re
import psycopg2
from datetime import datetime

LOG_PATTERN = re.compile(
    r'(?P<ip>\S+) \S+ \S+ \[(?P<time>.*?)\] '
    r'"(?P<method>\S+) (?P<url>\S+) (?P<protocol>\S+)" '
    r'(?P<status>\d+) (?P<size>\S+) '
    r'"(?P<referer>.*?)" "(?P<user_agent>.*?)"'
)

def parse_line(line):
    match = LOG_PATTERN.match(line)
    if not match:
        return None

    data = match.groupdict()

    timestamp = datetime.strptime(
        data["time"], "%d/%b/%Y:%H:%M:%S %z"
    )

    return (
        data["ip"],
        timestamp,
        data["method"],
        data["url"],
        data["protocol"],
        int(data["status"]),
        int(data["size"]) if data["size"].isdigit() else 0,
        data["referer"],
        data["user_agent"],
        line.strip()
    )


def load_file(filepath):
    conn = psycopg2.connect(
        host="127.0.0.1",
        dbname="etl_db",
        user="etl_user",
        password="etl_pass"
    )
    cursor = conn.cursor()

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f):
            parsed = parse_line(line)
            if not parsed:
                continue

            cursor.execute("""
                INSERT INTO raw_web_logs (
                    ip, timestamp, method, url, protocol,
                    status_code, response_size,
                    referer, user_agent, raw_line
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, parsed)

            if i % 1000 == 0:
                conn.commit()
                print(f"Inserted {i} rows")

    conn.commit()
    cursor.close()
    conn.close()
    print("Done!")


if __name__ == "__main__":
    load_file(r"C:\Users\Егор\PycharmProjects\pythonProject7\etl-web-logs\data\sample.log")