from pyspark.sql.functions import col, when, hour, to_date


def transform_web_logs(df):
    df = df.withColumn(
        "status_class",
        when(col("status_code").between(200, 299), "success")
        .when(col("status_code").between(300, 399), "redirect")
        .when(col("status_code").between(400, 499), "client_error")
        .when(col("status_code") >= 500, "server_error")
    )

    df = df.withColumn("event_date", to_date(col("timestamp")))
    df = df.withColumn("event_hour", hour(col("timestamp")))

    df = df.withColumn(
        "is_bot",
        col("user_agent").rlike("(?i)bot|crawler|spider")
    )

    df = df.filter(
        ~col("url").rlike(r"\.(jpg|jpeg|png|gif|css|js|ico)$")
    )

    return df